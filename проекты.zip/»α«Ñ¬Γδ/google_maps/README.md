# Google Maps API

Interacting with the Google Maps API for The Odin Project's [Project: Putting Google Maps Onto Your Site with Javascript](http://www.theodinproject.com/javascript-and-jquery/putting-google-maps-onto-your-site).

Place markers on the Map by entering latitude/longitude data and an optional message.  Click a created marker to see the marker's message (if present).

---

[Preview Google Maps here](http://htmlpreview.github.io/?https://github.com/donaldali/odin-js-jquery/blob/master/google_maps/index.html "Google Maps").
